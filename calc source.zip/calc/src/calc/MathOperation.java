package calc;

public class MathOperation {

    public double sum (double num1 , double num2){
    double sum_result = num1+num2;
    return sum_result;
        }
    public double sub (double num1 , double num2){
        double sub_result = num1-num2;
        return sub_result;
    }
    public double multipication (double num1 , double num2){
        double multi_result = num1*num2;
        return multi_result;
    }
    public double divide (double num1 , double num2){
        double divide_result=num1/num2;
        return divide_result;
        }
    public double percentage (double num1 , double num2){
        double divide_result=num1%num2;
        return divide_result;
    }
    
}
